local Config = {
    checkInterval = 2500,           -- Check every 1.5 seconds
    allowedDifference = 120,        -- 2 minutes tolerance on join
    allowedTimejump = 120,            -- Only 8 seconds jump allowed during gameplay
    kickMessage = "You are kicked from server for time-manipulation!",
    maxFailedChecks = 3,            -- Kick after 3 failed checks
}

-- Store last known time for each player
local playerLastTime = {}
local playerCheckCount = {}
local playerFailedChecks = {}

-- Function to kick player and clean data
local function kickPlayer(source, playerName, reason)
    TriggerClientEvent("timecheck:kickWarning", source, "TIME MANIPULATION DETECTED")
    
    Citizen.Wait(500)
    DropPlayer(source, Config.kickMessage)
    
    playerLastTime[source] = nil
    playerCheckCount[source] = nil
    playerFailedChecks[source] = nil
end

-- Event to receive and validate client time
RegisterNetEvent("timecheck:validateClientTime")
AddEventHandler("timecheck:validateClientTime", function(clientTimeUnix)
    local source = source
    local playerName = GetPlayerName(source)
    
    -- Check for invalid data or error signal
    if type(clientTimeUnix) ~= "number" or clientTimeUnix <= 0 then
        playerFailedChecks[source] = (playerFailedChecks[source] or 0) + 1
        if playerFailedChecks[source] >= Config.maxFailedChecks then
            kickPlayer(source, playerName, "Invalid time data")
        end
        return
    end
    
    -- Initialize counters
    if not playerCheckCount[source] then
        playerCheckCount[source] = 0
        playerFailedChecks[source] = 0
    end
    playerCheckCount[source] = playerCheckCount[source] + 1
    
    local serverTime = os.time()
    
    -- CHECK 1: Absolute Server-Client Time Difference
    local timeDifferenceAbsolute = math.abs(serverTime - clientTimeUnix)
    
    if timeDifferenceAbsolute > Config.allowedDifference then
        local reason = string.format("Server-Client Difference: %d seconds (Limit: %d)", 
            timeDifferenceAbsolute, Config.allowedDifference)
        kickPlayer(source, playerName, reason)
        return
    end
    
    -- CHECK 2: Time Jump Detection (During gameplay)
    if playerLastTime[source] then
        local lastClientTime = playerLastTime[source].time
        local lastCheckTime = playerLastTime[source].serverTime
        
        local clientTimePassed = clientTimeUnix - lastClientTime
        local serverTimePassed = serverTime - lastCheckTime
        
        -- CHECK 2.1: Time went backwards (more than 10 seconds)
        if clientTimePassed < -Config.allowedTimejump then
            local reason = string.format("TIME WENT BACKWARDS! Difference: %ds (Limit: -%ds)", 
                clientTimePassed, Config.allowedTimejump)
            kickPlayer(source, playerName, reason)
            return
        end
        
        -- CHECK 2.2: Time speed manipulation (time jumping forward/backward)
        local timePassedDifference = math.abs(clientTimePassed - serverTimePassed)
        
        -- During gameplay, be strict about time jumps
        if timePassedDifference > Config.allowedTimejump then
            playerFailedChecks[source] = (playerFailedChecks[source] or 0) + 1
            
            if playerFailedChecks[source] >= Config.maxFailedChecks then
                local reason = string.format("TIME JUMP: %ds", timePassedDifference)
                kickPlayer(source, playerName, reason)
                return
            end
        else
            -- Reset failed checks on successful validation
            playerFailedChecks[source] = 0
        end
        
        -- CHECK 2.3: Client time is frozen (not advancing)
        if serverTimePassed > 5 and clientTimePassed < 1 then
            local reason = "TIME FROZEN: Client time not advancing"
            kickPlayer(source, playerName, reason)
            return
        end
    end
    
    -- Store current time for next check
    playerLastTime[source] = {
        time = clientTimeUnix,
        serverTime = serverTime
    }
end)

-- Periodic check thread for all players
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(Config.checkInterval)
        
        local players = GetPlayers()
        
        for _, playerId in ipairs(players) do
            local pId = tonumber(playerId)
            if pId then
                TriggerClientEvent("timecheck:requestValidation", pId)
            end
        end
    end
end)

-- Check player on connect 
AddEventHandler("playerConnecting", function()
    local source = source
    
    playerLastTime[source] = nil
    playerCheckCount[source] = 0
    playerFailedChecks[source] = 0
    
    Citizen.SetTimeout(3000, function()
        if GetPlayerName(source) then
            TriggerClientEvent("timecheck:requestValidation", source)
        end
    end)
    
    Citizen.SetTimeout(5000, function()
        if GetPlayerName(source) then
            TriggerClientEvent("timecheck:requestValidation", source)
        end
    end)
end)

-- Clean up data when player disconnects
AddEventHandler("playerDropped", function(reason)
    local source = source
    if playerLastTime[source] then
        playerLastTime[source] = nil
        playerCheckCount[source] = nil
        playerFailedChecks[source] = nil
    end
end)

-- Log when resource starts
AddEventHandler("onResourceStart", function(resourceName)
    if GetCurrentResourceName() == resourceName then
        -- Silent start
    end
end)
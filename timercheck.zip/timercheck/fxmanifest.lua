fx_version 'cerulean'
game 'gta5'

description 'Time Checker-ILIRIA RP'
author 'RREMA'
version '2.0.0'


ui_page 'html/index.html'

files {
    'html/index.html'
}

server_scripts {
    'server.lua'
}

client_scripts {
    'client.lua'
}
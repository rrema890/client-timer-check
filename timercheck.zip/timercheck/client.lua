-- client.lua
-- Anti Time Manipulation System - NUI Method (Works on VPS)

local realSystemTime = 0
local lastTimeReceived = 0

-- Create NUI frame (invisible)
Citizen.CreateThread(function()
    SetNuiFocus(false, false)
    
    -- Start time updates
    while true do
        Citizen.Wait(800) -- Request every 800ms
        SendNUIMessage({
            action = "getTime"
        })
    end
end)

-- Receive time from NUI
RegisterNUICallback('sendTime', function(data, cb)
    if data.time then
        realSystemTime = math.floor(data.time / 1000) -- Convert to seconds
        lastTimeReceived = GetGameTimer()
    end
    cb('ok')
end)

-- Event to send client time to server
RegisterNetEvent("timecheck:requestValidation")
AddEventHandler("timecheck:requestValidation", function()
    -- Check if we received time recently (within 2 seconds)
    local timeSinceUpdate = GetGameTimer() - lastTimeReceived
    
    if realSystemTime > 0 and timeSinceUpdate < 2000 then
        TriggerServerEvent("timecheck:validateClientTime", realSystemTime)
    else
        TriggerServerEvent("timecheck:validateClientTime", -1)
    end
end)

-- Kick notification
RegisterNetEvent("timecheck:kickWarning")
AddEventHandler("timecheck:kickWarning", function(reason)
    print("[TimeCheck Client] " .. reason)
end)